<?php
if ( !class_exists( 'RasoloShipping' ) ) {
    class RasoloShipping{
	    static private $DB_OPTIONS_KEY = '_rasolo_shipping';
	    static public $TEXTDOMAIN = 'rasolo-shipping';
	    static private $CAPABILITY = 'edit_others_posts';

        private $api_key=false;
        private $msg_instance=false;

        function __construct(){
            $this_options=get_option(self::$DB_OPTIONS_KEY);
            if(!empty($this_options) && is_string($this_options)){
                $this->api_key=$this_options;
            }
            if(!class_exists('RasoloAdminMessages')){
                $this->msg_instance=new RasoloAdminMessages;
            };


        }

        public function admin_options_page(){
            if(!self::verify_user_access()){
                return;
            }
                       ?><div class="wrap">
<form method="post" class="rs_admin_form" novalidate="novalidate">
<h2 class="left_h1"><?php
    _e( 'Ra-Solo Shipping options', self::$TEXTDOMAIN );
    ?></h2>
<hr />
<table class="form-table" role="presentation">

<tbody><tr>
<th scope="row"><label for="rs_api_key"><?php
    _e( 'Ra-Solo API key', self::$TEXTDOMAIN );
    ?></label></th>
<td><input name="rs_api_key" type="text" id="rs_api_key" value="<?php
    echo $this->api_key;
    ?>"
 class="regular-text"></td>
</tr>
</table>
<p class="submit"><input type="submit" name="submit" id="submit"
 class="button button-primary" value="<?php
    _e( 'Save changes', self::$TEXTDOMAIN );
    ?>"></p>
</form>
</div><?php


        }   // The end of admin_options_page

        private static function verify_user_access(){
//	    	$min_cpb=$this->get_current_capability();
    		$min_cpb=self::$CAPABILITY;

            if(current_user_can($min_cpb)){
                return true;
            };
            return false;
    	} // The end of verify_user_access

        public function get_options_page_arguments(){
            $untranslatable_01='ru_RU'<>get_locale()?'Ra-Solo shipping plugin options page':'Страница настроек плагина доставки Ra-Solo';
            $opt_name=__( 'The rasolo shipping options', self::$TEXTDOMAIN );
            if('ru_RU'==get_locale()){
                $opt_name='Параметры плагина доставки &ndash; &laquo;Ra-Solo&raquo;';
            }
        return array(
            __( $untranslatable_01, self::$TEXTDOMAIN),
            $opt_name,
            self::$CAPABILITY,
            'rasolo_shipping_options_page',
            array($this, 'admin_options_page')
        );

        }

        private function put_adm_message($msg_txt,$msg_status='info',$msg_dismiss=false){
            if(empty($this->msg_instance)){
                return;
            }
            $this->msg_instance->set_message($msg_txt,$msg_status,$msg_dismiss);
        }


        private function save_data(){
            if(!self::verify_user_access()){
                return;
            }
            update_option(self::$DB_OPTIONS_KEY,$this->api_key);
        }

        public function process_post_data(){
            if(!self::verify_user_access()){
                return;
            }

            if(!empty($_POST['rs_api_key'])){
                $new_key_val=sanitize_text_field($_POST['rs_api_key']);
                if($new_key_val<>$this->api_key){
                    $this->api_key=$new_key_val;
                    $this->save_data();
                }
            }
        }

        public function get_key(){
            return $this->api_key;
        }
    }
}
